// backend/server.js
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const dbPath = path.join(__dirname, '../db/messages.db');
const db = new sqlite3.Database(dbPath);

// Create table if it doesn't exist
db.run(`
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sessionKey TEXT NOT NULL,
    message TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

// Serve frontend
app.use(express.static(path.join(__dirname, '../public')));

// Route: Post a message
app.post('/message/:sessionKey', (req, res) => {
  const sessionKey = req.params.sessionKey;
  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message is required.' });
  }

  db.run(
    `INSERT INTO messages (sessionKey, message) VALUES (?, ?)`,
    [sessionKey, message],
    function (err) {
      if (err) {
        return res.status(500).json({ error: 'Database error.' });
      }
      res.status(201).json({ message: 'Stored successfully', id: this.lastID });
    }
  );
});

// Route: Get messages
app.get('/messages/:sessionKey', (req, res) => {
  const sessionKey = req.params.sessionKey;

  db.all(
    `SELECT id, message, timestamp FROM messages WHERE sessionKey = ? ORDER BY id ASC`,
    [sessionKey],
    (err, rows) => {
      if (err) {
        return res.status(500).json({ error: 'Database error.' });
      }
      res.json(rows);
    }
  );
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
