// matrix.js

// Setup canvas
const canvas = document.createElement("canvas");
document.body.appendChild(canvas);
canvas.style.position = "fixed";
canvas.style.top = "0";
canvas.style.left = "0";
canvas.style.zIndex = "-1";
canvas.style.width = "100%";
canvas.style.height = "100%";

const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const letters = "アァカサタナハマヤャラワガザダバパイィキシチニヒミリヰギジヂビピウゥクスツヌフムユュルグズヅブプエェケセテネヘメレヱゲゼデベペオォコソトノホモヨョロヲゴゾドボポヴ".split("");
const fontSize = 14;
const columns = Math.floor(canvas.width / fontSize);
const drops = Array(columns).fill(1);

// Matrix rain animation
function drawMatrix() {
  ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#0F0";
  ctx.font = fontSize + "px monospace";

  for (let i = 0; i < drops.length; i++) {
    const text = letters[Math.floor(Math.random() * letters.length)];
    ctx.fillText(text, i * fontSize, drops[i] * fontSize);
    if (drops[i] * fontSize > canvas.height || Math.random() > 0.975) {
      drops[i] = 0;
    }
    drops[i]++;
  }
}

setInterval(drawMatrix, 35);

// === Add phrase banner and rotation ===

// Create banner container
const banner = document.createElement("div");
banner.className = "banner";
banner.innerHTML = `<span id="phrase">BE PRIVATE</span>`;
document.body.appendChild(banner);

// Style banner via JS
const style = document.createElement("style");
style.textContent = `

.banner {
  position: relative;
  z-index: 1;
  text-align: center;
  margin-top: 60px;
  font-size: 3rem;
  font-weight: bold;
  color: #00ff00;
  text-shadow: 0 0 10px #00ff00, 0 0 20px #00ff00;
  animation: pulse 2s infinite;
}



  @keyframes pulse {
    0% { text-shadow: 0 0 5px #00ff00; }
    50% { text-shadow: 0 0 20px #00ff00; }
    100% { text-shadow: 0 0 5px #00ff00; }
  }

  .fade-out {
    opacity: 0;
    transition: opacity 0.4s ease;
  }

  #phrase {
    transition: opacity 0.4s ease;
  }
`;
document.head.appendChild(style);

// Rotate phrases
const phrases = [
  "BE PRIVATE",
  "STAY SECURE",
  "OWN YOUR CONVERSATION",
  "LEAVE NO TRACE",
  "WATCHING YOU"
];

let phraseIndex = 0;
const phraseElement = document.getElementById("phrase");

setInterval(() => {
  phraseElement.classList.add("fade-out");

  setTimeout(() => {
    phraseIndex = (phraseIndex + 1) % phrases.length;
    phraseElement.textContent = phrases[phraseIndex];
    phraseElement.classList.remove("fade-out");
  }, 400);
}, 3000);

